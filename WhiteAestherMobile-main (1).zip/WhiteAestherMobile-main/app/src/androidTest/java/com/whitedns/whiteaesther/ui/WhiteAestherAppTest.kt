package com.whitedns.whiteaesther.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsFocused
import androidx.compose.ui.test.assertIsNotFocused
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.junit4.v2.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performKeyInput
import androidx.compose.ui.test.performSemanticsAction
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.pressKey
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.test.espresso.Espresso.pressBack
import com.whitedns.whiteaesther.AddressPair
import com.whitedns.whiteaesther.EndpointScannerState
import com.whitedns.whiteaesther.data.AppSettings
import com.whitedns.whiteaesther.data.Carrier
import com.whitedns.whiteaesther.data.EndpointMode
import com.whitedns.whiteaesther.service.EngineStage
import com.whitedns.whiteaesther.service.EngineStatus
import com.whitedns.whiteaesther.service.TrafficSample
import com.whitedns.whiteaesther.ui.theme.WhiteAestherTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class WhiteAestherAppTest {
    @get:Rule
    val compose = createComposeRule()

    private fun setApp(
        initial: AppSettings = AppSettings(),
        onScan: () -> Unit = {},
        onReset: () -> Unit = {},
        onSettings: (AppSettings) -> Unit = {},
        onConnect: () -> Unit = {},
        television: Boolean? = null,
        engineStatus: EngineStatus = EngineStatus(),
        addresses: AddressPair = AddressPair(),
        traffic: TrafficSample = TrafficSample(),
    ) {
        compose.setContent {
            WhiteAestherTheme {
                var current by remember { mutableStateOf(initial) }
                WhiteAestherApp(
                    settings = current,
                    engineStatus = engineStatus,
                    endpointScannerState = EndpointScannerState(),
                    nativeVersion = "1.8.0+android.0.2.0",
                    onSettingsChange = { current = it; onSettings(it) },
                    onConnect = { onConnect() },
                    onStop = {},
                    onScanEndpoints = { onScan() },
                    onTestEndpoint = {},
                    onResetEndpoint = { onReset() },
                    onCancelEndpointScan = {},
                    addresses = addresses,
                    traffic = traffic,
                    batteryExempt = true,
                    television = television,
                )
            }
        }
    }

    @Test
    fun homeOffersDirectConnectionControlsWithoutTechnicalDetails() {
        setApp()

        compose.onNodeWithTag("connect-orb").assertExists()
        compose.onNodeWithText("Not connected").assertExists()
        compose.onNodeWithTag("home-method").assertExists()
        compose.onNodeWithTag("home-mode").assertExists()
        compose.onNodeWithTag("home-connection-details").assertDoesNotExist()
        compose.onNodeWithTag("choice-adaptive").assertDoesNotExist()
    }

    @Test
    fun endpointLivesUnderProtocolAndAcceptsAnAddress() {
        setApp(AppSettings(endpointMode = EndpointMode.CUSTOM_FIRST))

        compose.openAdvanced("aether")
        compose.onNodeWithTag("routes-endpoint").performScrollTo().performClick()
        compose.onNodeWithTag("custom-endpoint-field").performScrollTo().performTextInput("162.159.197.3:443")
        compose.onNodeWithTag("custom-endpoint-field").assertTextContains("162.159.197.3:443")
        // The field reports its own validation, which is the point of typing a valid one.
        compose.onNodeWithText("Valid address").assertExists()
    }

    @Test
    fun endpointScanCanBeStarted() {
        var scanRequested = false
        setApp(onScan = { scanRequested = true })

        compose.openAdvanced("aether")
        compose.onNodeWithTag("routes-endpoint").performScrollTo().performClick()
        compose.onNodeWithTag("scan-endpoints-button").performScrollTo().performClick()
        compose.runOnIdle { assertTrue(scanRequested) }
    }

    @Test
    fun forgettingTheEndpointClearsTheFieldAndAsksForAFreshSearch() {
        var resetRequested = false
        setApp(
            initial = AppSettings(
                endpointMode = EndpointMode.CUSTOM_FIRST,
                customEndpoint = "162.159.197.3:443",
            ),
            onReset = { resetRequested = true },
        )

        compose.openAdvanced("aether")
        compose.onNodeWithTag("routes-endpoint").performScrollTo().performClick()
        compose.onNodeWithTag("custom-endpoint-field").assertTextContains("162.159.197.3:443")
        compose.onNodeWithTag("reset-endpoint-button").performScrollTo().performClick()
        compose.runOnIdle { assertTrue(resetRequested) }
        // The field is cleared with the setting, not left showing an address
        // the app has just been told to forget.
        compose.onNodeWithTag("custom-endpoint-field").assertTextContains("")
    }

    @Test
    fun theCarrierCanBeChosenAndIsCarriedIntoTheSettings() {
        var saved: AppSettings? = null
        setApp(onSettings = { saved = it })

        compose.onNodeWithTag("home-method").performClick()
        compose.onNodeWithTag("option-psiphon").performScrollTo().performClick()
        compose.runOnIdle { assertEquals(Carrier.PSIPHON, saved?.carrier) }
    }

    @Test
    fun choosingACarrierSaysTheEngineControlsNoLongerApply() {
        // The endpoint, the protocol and the discovery depth all describe a
        // search for a Cloudflare gateway. A carrier that never looks for one
        // leaves that whole half of the screen inert, and a screen full of
        // controls that quietly do nothing is worse than a sentence saying so.
        setApp(initial = AppSettings(carrier = Carrier.PSIPHON, automaticCarrier = false))

        compose.openAdvanced("aether")
        compose.onNodeWithTag("protocol-not-in-use").assertExists()
    }

    @Test
    fun aetherIsTheCarrierUntilSomethingSaysOtherwise() {
        // The default matters more than it looks. Psiphon is somebody else's
        // network, and an install that silently began using it would be a
        // decision made for the user rather than by them.
        assertEquals(Carrier.AETHER, AppSettings().carrier)

        setApp()
        compose.onNodeWithTag("home-method").performClick()
        compose.onNodeWithTag("option-aether").performScrollTo().assertExists()
    }

    @Test
    fun advancedTrafficControlsLiveUnderSettingsAdvanced() {
        setApp()

        compose.onNodeWithTag("proxy-port-field").assertDoesNotExist()
        compose.openAdvanced("network")
        compose.onNodeWithTag("proxy-port-field").performScrollTo().assertExists()
        pressBack()
        compose.onNodeWithTag("advanced-safety").performScrollTo().performClick()
        compose.onNodeWithTag("validation-switch").performScrollTo().assertIsOn()
    }

    @Test
    fun profileSelectionWritesRealEngineSettings() {
        var saved: AppSettings? = null
        setApp(onSettings = { saved = it })

        compose.onNodeWithTag("home-method").performClick()
        compose.onNodeWithTag("option-aether").performScrollTo().performClick()
        compose.onNodeWithTag("aether-profile-STRICT").performScrollTo().performClick()
        compose.runOnIdle {
            assertEquals(com.whitedns.whiteaesther.data.ScanStrategy.STEALTH, saved?.scanStrategy)
            assertEquals(com.whitedns.whiteaesther.data.TunnelProtocol.H2, saved?.transport)
        }
    }

    @Test
    fun tvStartsOnTheConnectionOrbAndCentreConnectsOnce() {
        var requests = 0
        setApp(television = true, onConnect = { requests++ })

        compose.onNodeWithTag("connect-orb")
            .assertIsFocused()
            .performKeyInput { pressKey(Key.DirectionCenter) }

        compose.runOnIdle { assertEquals(1, requests) }
    }

    @Test
    fun tvCanFocusAndScrollPastConnectedTimeToTheLastHomeCard() {
        setApp(
            television = true,
            engineStatus = EngineStatus(
                stage = EngineStage.CONNECTED,
                message = "Whole-device traffic is protected",
                connectedAtMillis = System.currentTimeMillis() - 65_000,
            ),
            addresses = AddressPair(real = "198.51.100.10", tunnel = "203.0.113.20"),
            traffic = TrafficSample(received = 4_096, sent = 2_048),
        )

        compose.onNodeWithTag("connect-orb").assertIsFocused()
        compose.onNodeWithTag("home-details-toggle")
            .performScrollTo()
            .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
            .assertIsFocused()
            .performKeyInput { pressKey(Key.DirectionCenter) }
        compose.onNodeWithTag("home-address").performScrollTo().assertIsDisplayed()
        compose.onNodeWithTag("home-connection-details").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun tvTabSelectionKeepsRemoteFocusOnTheSelectedTab() {
        setApp(television = true)

        compose.onNodeWithTag("tab-home")
            .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
            .assertIsFocused()
            .performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithTag("tab-apps")
            .assertIsFocused()
            .performKeyInput { pressKey(Key.DirectionCenter) }

        compose.onNodeWithTag("tab-apps").assertIsFocused()
        compose.onNodeWithTag("split-app-list").assertExists()

        compose.onNodeWithTag("tab-home")
            .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
            .performKeyInput { pressKey(Key.DirectionCenter) }
            .assertIsFocused()
        compose.onNodeWithText("Not connected").assertExists()
    }

    @Test
    fun tvProfileChoicesActivateFromOneRemoteTarget() {
        var writes = 0
        setApp(television = true, onSettings = { writes++ })
        compose.onNodeWithTag("home-method").performScrollTo().performClick()

        // Choosing Aether is one write, its profile chip another.
        listOf("option-aether", "aether-profile-STRICT").forEach { tag ->
            compose.onNodeWithTag(tag)
                .performScrollTo()
                .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
                .assertIsFocused()
                .performKeyInput { pressKey(Key.DirectionCenter) }
        }

        compose.runOnIdle { assertEquals(2, writes) }
    }

    @Test
    fun tvBackReturnsToTheOriginatingDetailRow() {
        setApp(television = true)
        compose.openAdvanced("aether")
        compose.onNodeWithTag("routes-endpoint")
            .performScrollTo()
            .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
            .performKeyInput { pressKey(Key.DirectionCenter) }

        compose.onNodeWithText("Where it connects to").assertExists()
        pressBack()

        compose.onNodeWithTag("routes-endpoint").assertIsFocused()
    }

    @Test
    fun tvFocusBringsLongSettingsContentIntoViewAndHidesTileSetup() {
        setApp(initial = AppSettings(showAdvanced = true), television = true)
        compose.openAdvanced("aether")
        compose.onNodeWithTag("aether-stealth").performScrollTo().performClick()

        compose.onNodeWithTag("fragment-tls-switch")
            .performScrollTo()
            .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
            .assertIsFocused()

        compose.onNodeWithTag("fragment-tls-switch")
            .performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithTag("ech-switch")
            .assertIsFocused()
            .assertIsDisplayed()

        compose.onNodeWithTag("tab-settings").performClick()
        compose.onNodeWithTag("add-tile-button").assertDoesNotExist()
    }

    @Test
    fun tvGamepadButtonsActivateAndNavigateBack() {
        var requests = 0
        setApp(television = true, onConnect = { requests++ })

        compose.onNodeWithTag("connect-orb")
            .assertIsFocused()
            .performKeyInput { pressKey(Key.ButtonA) }
        compose.runOnIdle { assertEquals(1, requests) }

        compose.onNodeWithTag("tab-settings")
            .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
            .performKeyInput { pressKey(Key.ButtonA) }
        listOf("settings-advanced", "advanced-aether").forEach { tag ->
            compose.onNodeWithTag(tag)
                .performScrollTo()
                .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
                .performKeyInput { pressKey(Key.ButtonA) }
        }
        compose.onNodeWithTag("routes-endpoint")
            .performScrollTo()
            .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
            .performKeyInput { pressKey(Key.ButtonA) }
        compose.onNodeWithText("Where it connects to").assertExists()

        compose.onNodeWithTag("back-button")
            .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
            .performKeyInput { pressKey(Key.ButtonB) }
        compose.onNodeWithTag("routes-endpoint").assertIsFocused()
    }

    @Test
    fun tvChoosesTheMethodOnAPageInsteadOfASheet() {
        var saved: AppSettings? = null
        setApp(television = true, onSettings = { saved = it })

        compose.onNodeWithTag("home-method").performScrollTo().performClick()
        compose.onNodeWithTag("option-aether")
            .performScrollTo()
            .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
            .performKeyInput { pressKey(Key.DirectionCenter) }

        compose.runOnIdle {
            assertEquals(Carrier.AETHER, saved?.carrier)
            assertEquals(false, saved?.automaticCarrier)
        }
        compose.onNodeWithTag("aether-profiles").assertExists()
        compose.onNodeWithTag("method-done")
            .performScrollTo()
            .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
            .performKeyInput { pressKey(Key.DirectionCenter) }
        compose.onNodeWithTag("connect-orb").assertExists()
    }

    @Test
    fun tvRoutingRuleFieldCanMoveDownWithoutTouch() {
        setApp(television = true)

        compose.openAdvanced("routing")
        compose.onNodeWithTag("route-block-field")
            .performSemanticsAction(SemanticsActions.RequestFocus) { it.invoke() }
            .assertIsFocused()
            .performKeyInput { pressKey(Key.DirectionDown) }

        compose.onNodeWithTag("route-block-field").assertIsNotFocused()
        compose.onNodeWithTag("route-direct-field").assertIsFocused()
    }
}
