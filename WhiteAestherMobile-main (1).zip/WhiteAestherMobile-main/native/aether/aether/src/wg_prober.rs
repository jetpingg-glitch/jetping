use std::collections::HashSet;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use futures::stream::StreamExt;
use rand::RngExt;

use crate::aethernoize::AetherNoizeConfig;
use crate::error::{AetherError, Result};
use crate::prober::IpScan;
use crate::wireguard;

/// Why probes failed, counted rather than logged one at a time.
///
/// A scan makes thousands of attempts, so logging each is unusable -- but the
/// distribution of failures is the entire diagnosis. Every probe timing out
/// means packets left the device and nothing came back, which is a blocked or
/// filtered path. Every probe failing to send means they never left at all,
/// which is this device's own routing. Those have opposite fixes, and until now
/// the log collapsed both into "no clean endpoint found".
#[derive(Default)]
pub struct ProbeTally {
    /// Sent, and nothing ever came back.
    silent: AtomicUsize,
    /// The socket could not send: no route, or the OS refused.
    unreachable: AtomicUsize,
    /// Android declined to protect the socket, so it would have gone into the
    /// tunnel we are trying to replace.
    unprotected: AtomicUsize,
    /// Something answered, but the handshake or the data check did not finish.
    rejected: AtomicUsize,
    other: AtomicUsize,
}

impl ProbeTally {
    fn record(&self, error: &AetherError) {
        let counter = match error {
            AetherError::Other(message) if message.contains("rejected upstream socket") => {
                &self.unprotected
            }
            AetherError::Other(message) if message.contains("verify timeout") => &self.silent,
            AetherError::Io(io) => match io.kind() {
                std::io::ErrorKind::NetworkUnreachable
                | std::io::ErrorKind::HostUnreachable
                | std::io::ErrorKind::AddrNotAvailable
                | std::io::ErrorKind::PermissionDenied => &self.unreachable,
                std::io::ErrorKind::TimedOut | std::io::ErrorKind::WouldBlock => &self.silent,
                _ => &self.other,
            },
            _ => &self.other,
        };
        counter.fetch_add(1, Ordering::Relaxed);
    }

    fn reset(&self) {
        for counter in self.all() {
            counter.store(0, Ordering::Relaxed);
        }
    }

    fn all(&self) -> [&AtomicUsize; 5] {
        [
            &self.silent,
            &self.unreachable,
            &self.unprotected,
            &self.rejected,
            &self.other,
        ]
    }

    fn describe(&self) -> String {
        let read = |counter: &AtomicUsize| counter.load(Ordering::Relaxed);
        format!(
            "no reply={} could not send={} refused by vpn={} handshake refused={} \
             other={} opened with no protector={}",
            read(&self.silent),
            read(&self.unreachable),
            read(&self.unprotected),
            read(&self.rejected),
            read(&self.other),
            crate::socketprotect::unprotected_count(),
        )
    }
}

/// Shared because probes run on many tasks and the classes matter, not which
/// address produced which. Passes are sequential, so one tally is enough.
pub static PROBE_TALLY: ProbeTally = ProbeTally {
    silent: AtomicUsize::new(0),
    unreachable: AtomicUsize::new(0),
    unprotected: AtomicUsize::new(0),
    rejected: AtomicUsize::new(0),
    other: AtomicUsize::new(0),
};

/// Forgets the previous pass, so a summary describes only the one just run.
pub fn begin_probe_pass() {
    PROBE_TALLY.reset();
    crate::socketprotect::reset_unprotected_count();
}

/// One line saying how the pass failed, for the diagnostics report.
pub fn probe_pass_summary() -> String {
    PROBE_TALLY.describe()
}

/// Counts a failure that happened outside `verify_one_wg`.
pub fn record_probe_failure(error: &AetherError) {
    PROBE_TALLY.record(error);
}

#[derive(Debug, Clone, Copy)]
pub struct WgProbeResult {
    pub ip: IpAddr,
    pub port: u16,
    pub rtt: Duration,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WgScanMode {
    Turbo,
    Balanced,
    Thorough,
    Verified,
    Ironclad,
}

impl WgScanMode {
    pub fn parse(s: &str) -> WgScanMode {
        match s.trim().to_lowercase().as_str() {
            "turbo" | "fast" => WgScanMode::Turbo,
            "thorough" | "deep" | "pro" => WgScanMode::Thorough,
            "verified" | "proven" | "stealth" | "quiet" => WgScanMode::Verified,
            "ironclad" | "real" | "verify" | "guaranteed" => WgScanMode::Ironclad,
            _ => WgScanMode::Balanced,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            WgScanMode::Turbo => "turbo",
            WgScanMode::Balanced => "balanced",
            WgScanMode::Thorough => "thorough",
            WgScanMode::Verified => "verified",
            WgScanMode::Ironclad => "ironclad",
        }
    }

    /// Concurrency and overall budget, for the cross-prober comparison in
    /// `lib.rs`. The two strategies are private and differently shaped; this is
    /// the pair that decides how much of the space gets searched.
    #[cfg(test)]
    pub(crate) fn strategy_for_test(&self) -> (usize, Duration) {
        let s = self.strategy();
        (s.concurrency, s.overall_deadline)
    }

    fn strategy(&self) -> WgStrategy {
        match self {
            WgScanMode::Turbo => WgStrategy {
                concurrency: 20,
                per_probe_timeout: Duration::from_millis(5000),
                overall_deadline: Duration::from_secs(30),
                quiet_after_first: Duration::from_secs(0),
                target_successes: 1,
                early_exit_first: true,
                full_subnet: false,
                sample_per_cidr: 40,
                pool_port_waves: 1,
            },
            // Sixteen and two minutes, matching the MASQUE prober. WireGuard
            // searches a larger space -- fifty-four ports against MASQUE's
            // handful -- and was given half the concurrency and two thirds the
            // budget, which covered about one candidate in forty before giving
            // up. Failure was close to arithmetic rather than evidence the
            // network was blocking anything.
            WgScanMode::Balanced => WgStrategy {
                concurrency: 16,
                per_probe_timeout: Duration::from_millis(6000),
                overall_deadline: Duration::from_secs(120),
                quiet_after_first: Duration::from_secs(12),
                target_successes: 5,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 120,
                pool_port_waves: 3,
            },
            WgScanMode::Thorough => WgStrategy {
                concurrency: 10,
                per_probe_timeout: Duration::from_millis(9000),
                overall_deadline: Duration::from_secs(250),
                quiet_after_first: Duration::from_secs(25),
                target_successes: 0,
                early_exit_first: false,
                full_subnet: true,
                sample_per_cidr: 0,
                pool_port_waves: 4,
            },
            WgScanMode::Verified => WgStrategy {
                concurrency: 10,
                per_probe_timeout: Duration::from_millis(5000),
                overall_deadline: Duration::from_secs(60),
                quiet_after_first: Duration::from_secs(8),
                target_successes: 6,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 48,
                pool_port_waves: 4,
            },
            WgScanMode::Ironclad => WgStrategy {
                concurrency: 4,
                per_probe_timeout: Duration::from_millis(15000),
                overall_deadline: Duration::from_secs(180),
                quiet_after_first: Duration::from_secs(15),
                target_successes: 3,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 120,
                pool_port_waves: 3,
            },
        }
    }
}

const WG_IRONCLAD_TCPING_TIMEOUT: Duration = Duration::from_secs(10);

struct WgStrategy {
    concurrency: usize,
    per_probe_timeout: Duration,
    overall_deadline: Duration,
    quiet_after_first: Duration,
    target_successes: usize,
    early_exit_first: bool,
    full_subnet: bool,
    sample_per_cidr: usize,
    pool_port_waves: usize,
}

#[derive(Clone)]
pub struct WgProbe {
    pub private_key: Arc<[u8; 32]>,
    pub peer_public_key: Arc<[u8; 32]>,
    pub client_id: [u8; 3],
    pub local_ipv4: Ipv4Addr,
    pub aethernoize: AetherNoizeConfig,
    pub ports: Vec<u16>,
    pub ip: IpScan,
    pub excluded: HashSet<SocketAddr>,
}

pub async fn hunt_best_wg_endpoint(probe: &WgProbe, mode: WgScanMode) -> Result<WgProbeResult> {
    hunt_wg_endpoints(probe, mode, 1)
        .await?
        .into_iter()
        .next()
        .ok_or(AetherError::NoCleanEndpoint)
}

pub async fn hunt_wg_endpoints(
    probe: &WgProbe,
    mode: WgScanMode,
    want: usize,
) -> Result<Vec<WgProbeResult>> {
    let want = want.max(1);
    let mut st = mode.strategy();
    st.concurrency = crate::sysprofile::cap_concurrency(st.concurrency);
    let timeout = st.per_probe_timeout;
    let mut effective_ip = probe.ip;
    if probe.ip.want_v6() && !crate::prober::host_has_ipv6().await {
        if probe.ip.want_v4() {
            log::warn!("[-] host has no IPv6 route; falling back to IPv4-only scan");
            effective_ip = IpScan::V4;
        } else {
            log::warn!("[-] host has no IPv6 route; IPv6 scan needs native IPv6 connectivity");
            return Err(AetherError::NoCleanEndpoint);
        }
    }
    let candidates = build_wg_candidates(&st, &probe.ports, effective_ip, &probe.excluded);

    log::info!(
        "[*] wireguard scan mode={} ip={} candidates={} ports={:?} concurrency={} per_probe={:?} budget={:?}",
        mode.label(),
        effective_ip.label(),
        candidates.len(),
        probe.ports,
        st.concurrency,
        st.per_probe_timeout,
        st.overall_deadline,
    );

    let ironclad = mode == WgScanMode::Ironclad;

    let stream = futures::stream::iter(
        candidates
            .into_iter()
            .map(|(ip, port)| verify_one_wg(probe, ip, port, timeout, ironclad)),
    )
    .buffer_unordered(st.concurrency);
    tokio::pin!(stream);

    if want > 1 {
        st.early_exit_first = false;
        st.target_successes = st.target_successes.max(want * 3);
    }

    let deadline = Instant::now() + st.overall_deadline;
    let mut verified: Vec<WgProbeResult> = Vec::new();
    let mut found = 0usize;
    let mut quiet_until: Option<Instant> = None;

    loop {
        let effective = match quiet_until {
            Some(q) => q.min(deadline),
            None => deadline,
        };
        let remaining = effective.saturating_duration_since(Instant::now());
        if remaining.is_zero() {
            if !verified.is_empty() {
                if quiet_until.is_some() {
                    log::info!("[+] no new endpoints recently, finalizing selection");
                } else {
                    log::warn!("[-] scan deadline reached");
                }
            } else {
                log::warn!("[-] scan deadline reached with no endpoint");
            }
            break;
        }

        tokio::select! {
            item = stream.next() => {
                match item {
                    None => break,
                    Some(None) => continue,
                    Some(Some(pr)) => {
                        log::info!("[+] wg candidate ok {}:{} rtt={:?}", pr.ip, pr.port, pr.rtt);
                        if st.early_exit_first {
                            return Ok(vec![pr]);
                        }
                        verified.push(pr);
                        found += 1;

                        if distinct_by_ip(&verified).len() >= want && want > 1 {
                            log::info!("[+] found {want} endpoints on separate addresses");
                            break;
                        }


                        if st.target_successes > 0 && found >= st.target_successes && quiet_until.is_none() {
                            log::info!("[+] reached target of {} endpoints, selecting best", st.target_successes);
                            if !st.quiet_after_first.is_zero() {
                                quiet_until = Some(Instant::now() + st.quiet_after_first);
                            } else {
                                break;
                            }
                        }
                    }
                }
            }
            _ = tokio::time::sleep(remaining) => {
                if !verified.is_empty() {
                    if quiet_until.is_some() {
                        log::info!("[+] no new endpoints recently, finalizing selection");
                    } else {
                        log::warn!("[-] scan deadline reached");
                    }
                } else {
                    log::warn!("[-] scan deadline reached with no endpoint");
                }
                break;
            }
        }
    }

    let picked = distinct_by_ip(&verified);
    if picked.is_empty() {
        return Err(AetherError::NoCleanEndpoint);
    }

    for pr in picked.iter().take(want) {
        log::info!("[+] wg endpoint {}:{} rtt={:?}", pr.ip, pr.port, pr.rtt);
    }

    Ok(picked.into_iter().take(want).collect())
}

fn distinct_by_ip(found: &[WgProbeResult]) -> Vec<WgProbeResult> {
    let mut sorted = found.to_vec();
    sorted.sort_by_key(|pr| pr.rtt);

    let mut seen = std::collections::HashSet::new();
    sorted.into_iter().filter(|pr| seen.insert(pr.ip)).collect()
}

/// Every endpoint that answers, best first, rather than only the best one.
///
/// [`hunt_best_wg_endpoint`] exists to start a tunnel and stops as soon as it
/// has an answer it likes. This one is for the endpoint list a user picks from,
/// so it keeps collecting until the limit, the deadline, or a cancellation --
/// the same shape as the MASQUE scanner, so the app can drive both the same way.
pub async fn scan_wg_endpoints(
    probe: &WgProbe,
    mode: WgScanMode,
    limit: usize,
    cancelled: &std::sync::atomic::AtomicBool,
) -> Result<Vec<WgProbeResult>> {
    scan_wg_endpoints_observed(probe, mode, limit, cancelled, &|_| {}).await
}

pub async fn scan_wg_endpoints_observed(
    probe: &WgProbe,
    mode: WgScanMode,
    limit: usize,
    cancelled: &std::sync::atomic::AtomicBool,
    observer: crate::scan::ScanObserver<'_>,
) -> Result<Vec<WgProbeResult>> {
    let mut st = mode.strategy();
    st.concurrency = crate::sysprofile::cap_concurrency(st.concurrency);
    // Stopping at the first hit is right for connecting and wrong for listing.
    st.early_exit_first = false;
    let timeout = st.per_probe_timeout;

    let mut effective_ip = probe.ip;
    if probe.ip.want_v6() && !crate::prober::host_has_ipv6().await {
        if probe.ip.want_v4() {
            log::warn!("[-] host has no IPv6 route; falling back to IPv4-only scan");
            effective_ip = IpScan::V4;
        } else {
            return Err(AetherError::NoCleanEndpoint);
        }
    }
    let candidates = build_wg_candidates(&st, &probe.ports, effective_ip, &probe.excluded);
    log::info!(
        "[*] wireguard endpoint scan mode={} ip={} candidates={} limit={}",
        mode.label(),
        effective_ip.label(),
        candidates.len(),
        limit,
    );

    let ironclad = mode == WgScanMode::Ironclad;
    begin_probe_pass();
    let started = Instant::now();
    let mut progress = crate::scan::ScanProgress::new(candidates.len());
    progress.publish(started, String::new(), observer);
    let stream = futures::stream::iter(
        candidates
            .into_iter()
            .map(|(ip, port)| verify_one_wg(probe, ip, port, timeout, ironclad)),
    )
    .buffer_unordered(st.concurrency);
    tokio::pin!(stream);

    let deadline = Instant::now() + st.overall_deadline;
    let mut found: Vec<WgProbeResult> = Vec::new();

    loop {
        if cancelled.load(std::sync::atomic::Ordering::Relaxed) {
            log::info!("[*] wireguard scan cancelled");
            break;
        }
        if limit > 0 && found.len() >= limit {
            break;
        }
        let remaining = deadline.saturating_duration_since(Instant::now());
        if remaining.is_zero() {
            break;
        }

        tokio::select! {
            item = stream.next() => match item {
                None => break,
                Some(None) => {
                    progress.completed += 1;
                    progress.publish(started, probe_pass_summary(), observer);
                },
                Some(Some(result)) => {
                    progress.completed += 1;
                    progress.hit(SocketAddr::new(result.ip, result.port), result.rtt);
                    progress.publish(started, probe_pass_summary(), observer);
                    log::info!("[+] wg endpoint ok {}:{} rtt={:?}", result.ip, result.port, result.rtt);
                    found.push(result);
                }
            },
            _ = tokio::time::sleep(remaining) => break,
            _ = tokio::time::sleep(Duration::from_millis(100)) => {},
        }
    }

    found.sort_by_key(|result| result.rtt);
    if found.is_empty() {
        // The one line that says which kind of failure this was.
        log::info!("[-] wireguard scan found nothing: {}", probe_pass_summary());
        return Err(AetherError::Other(format!(
            "no working WireGuard endpoint: {}",
            probe_pass_summary()
        )));
    }
    Ok(found)
}

async fn verify_one_wg(
    probe: &WgProbe,
    ip: IpAddr,
    port: u16,
    timeout: Duration,
    ironclad: bool,
) -> Option<WgProbeResult> {
    let peer = SocketAddr::new(ip, port);

    let (rtt, session) = match wireguard::verify_endpoint_keep_session(
        peer,
        *probe.private_key,
        *probe.peer_public_key,
        probe.client_id,
        probe.local_ipv4,
        &probe.aethernoize,
        timeout,
        None,
    )
    .await
    {
        Ok(v) => v,
        Err(e) => {
            log::trace!("wg probe {ip}:{port} -> {e}");
            PROBE_TALLY.record(&e);
            return None;
        }
    };

    if !ironclad {
        return Some(WgProbeResult { ip, port, rtt });
    }

    let params = crate::tunnelping::WgPingParams {
        local_ipv4: probe.local_ipv4,
        local_ipv6: "::1".parse().unwrap(),
        aethernoize: probe.aethernoize.clone(),
    };
    match crate::tunnelping::wg_http_ping_established(session, &params, WG_IRONCLAD_TCPING_TIMEOUT)
        .await
    {
        Ok(http_rtt) => {
            log::info!(
                "[+] ironclad verified wg {ip}:{port} real http round trip rtt={:?}",
                http_rtt
            );
            Some(WgProbeResult {
                ip,
                port,
                rtt: http_rtt,
            })
        }
        Err(e) => {
            log::trace!("[-] ironclad wg {ip}:{port} failed real http check: {e}");
            PROBE_TALLY.rejected.fetch_add(1, Ordering::Relaxed);
            None
        }
    }
}

fn build_wg_candidates(
    st: &WgStrategy,
    ports: &[u16],
    ip: IpScan,
    excluded: &HashSet<SocketAddr>,
) -> Vec<(IpAddr, u16)> {
    let ports: Vec<u16> = {
        let mut seen_port: HashSet<u16> = HashSet::new();
        let deduped: Vec<u16> = ports
            .iter()
            .copied()
            .filter(|p| seen_port.insert(*p))
            .collect();
        if deduped.is_empty() {
            vec![2408]
        } else {
            deduped
        }
    };

    let mut anchors: Vec<IpAddr> = Vec::new();
    let mut pool: Vec<IpAddr> = Vec::new();

    if ip.want_v4() {
        for s in wireguard::wg_seeds_v4() {
            if let Ok(a) = s.parse::<Ipv4Addr>() {
                anchors.push(IpAddr::V4(a));
            }
        }
        let cidr_hosts: Vec<Vec<Ipv4Addr>> = wireguard::wg_prefixes_v4()
            .iter()
            .map(|c| {
                if st.full_subnet {
                    enumerate_cidr_v4(c)
                } else {
                    sample_cidr_v4(c, st.sample_per_cidr)
                }
            })
            .collect();
        let max_len = cidr_hosts.iter().map(|v| v.len()).max().unwrap_or(0);
        for i in 0..max_len {
            for hosts in &cidr_hosts {
                if let Some(a) = hosts.get(i) {
                    pool.push(IpAddr::V4(*a));
                }
            }
        }
    }

    if ip.want_v6() {
        for s in wireguard::WG_SEEDS_V6 {
            if let Ok(a) = s.parse::<Ipv6Addr>() {
                anchors.push(IpAddr::V6(a));
            }
        }
        let per = if st.sample_per_cidr == 0 {
            80
        } else {
            st.sample_per_cidr
        };
        let cidr6: Vec<Vec<Ipv6Addr>> = wireguard::wg_prefixes_v6()
            .iter()
            .map(|c| sample_cidr_v6(c, per, wireguard::WG_PREFIXES_V4))
            .collect();
        let max6 = cidr6.iter().map(|v| v.len()).max().unwrap_or(0);
        for i in 0..max6 {
            for hosts in &cidr6 {
                if let Some(a) = hosts.get(i) {
                    pool.push(IpAddr::V6(*a));
                }
            }
        }
    }

    let mut out: Vec<(IpAddr, u16)> = Vec::new();
    let mut seen: HashSet<(IpAddr, u16)> = HashSet::new();
    let port_count = ports.len();

    let mut push = |ip: IpAddr, port: u16| {
        if !excluded.contains(&SocketAddr::new(ip, port)) && seen.insert((ip, port)) {
            out.push((ip, port));
        }
    };

    let mut seen_ip: HashSet<IpAddr> = HashSet::new();
    let ips: Vec<IpAddr> = anchors
        .iter()
        .chain(pool.iter())
        .copied()
        .filter(|ip| seen_ip.insert(*ip))
        .collect();

    for wave in 0..st.pool_port_waves.max(1) {
        for (idx, candidate_ip) in ips.iter().enumerate() {
            push(*candidate_ip, ports[(idx + wave) % port_count]);
        }
    }

    out
}

fn parse_cidr_v4(cidr: &str) -> Option<(u32, u8)> {
    let (ip, prefix) = cidr.split_once('/')?;
    Some((
        u32::from(ip.parse::<Ipv4Addr>().ok()?),
        prefix.parse().ok()?,
    ))
}

fn enumerate_cidr_v4(cidr: &str) -> Vec<Ipv4Addr> {
    let (base, prefix) = match parse_cidr_v4(cidr) {
        Some(v) => v,
        None => return Vec::new(),
    };
    let host_bits = 32u32.saturating_sub(prefix as u32);
    if host_bits == 0 {
        return vec![Ipv4Addr::from(base)];
    }
    if host_bits > 12 {
        return Vec::new();
    }
    let size = 1u32 << host_bits;
    (1..size.saturating_sub(1))
        .map(|off| Ipv4Addr::from(base + off))
        .collect()
}

fn sample_cidr_v4(cidr: &str, n: usize) -> Vec<Ipv4Addr> {
    let (base, prefix) = match parse_cidr_v4(cidr) {
        Some(v) => v,
        None => return Vec::new(),
    };
    let host_bits = 32u32.saturating_sub(prefix as u32);
    let size = if host_bits >= 32 {
        u32::MAX
    } else {
        1u32 << host_bits
    };
    if size <= 2 {
        return vec![Ipv4Addr::from(base)];
    }

    let usable = size - 2;
    let want = (n as u32).min(usable);
    let mut rng = rand::rng();
    let mut chosen: HashSet<u32> = HashSet::with_capacity(want as usize);
    let mut out = Vec::with_capacity(want as usize);

    while (out.len() as u32) < want {
        let off = 1 + rng.random_range(0..usable);
        if chosen.insert(off) {
            out.push(Ipv4Addr::from(base + off));
        }
    }

    out
}

fn parse_cidr_v6(cidr: &str) -> Option<(u128, u8)> {
    let (ip, prefix) = cidr.split_once('/')?;
    Some((
        u128::from(ip.parse::<Ipv6Addr>().ok()?),
        prefix.parse().ok()?,
    ))
}

fn sample_cidr_v6(cidr: &str, n: usize, v4_cidrs: &[&str]) -> Vec<Ipv6Addr> {
    let (base, prefix) = match parse_cidr_v6(cidr) {
        Some(v) => v,
        None => return Vec::new(),
    };
    if 128u32.saturating_sub(prefix as u32) == 0 {
        return vec![Ipv6Addr::from(base)];
    }

    let v4: Vec<(u32, u8)> = v4_cidrs.iter().filter_map(|c| parse_cidr_v4(c)).collect();
    let mut rng = rand::rng();
    let mut out = Vec::with_capacity(n);
    for _ in 0..n {
        let embedded = if v4.is_empty() {
            rng.random::<u32>() as u128
        } else {
            let (b, p) = v4[rng.random_range(0..v4.len())];
            let host_bits = 32u32.saturating_sub(p as u32);
            let host = if host_bits == 0 {
                0
            } else {
                rng.random::<u32>() & ((1u32 << host_bits) - 1)
            };
            (b | host) as u128
        };
        out.push(Ipv6Addr::from(base | embedded));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;

    #[test]
    fn anchors_come_first_but_each_on_its_own_port() {
        let strategy = WgScanMode::Turbo.strategy();
        let ports = [2408, 500, 1701, 4500, 854];
        let candidates = build_wg_candidates(&strategy, &ports, IpScan::V4, &HashSet::new());

        for (idx, seed) in wireguard::wg_seeds_v4().iter().enumerate() {
            let ip = IpAddr::V4(seed.parse().expect("wireguard seed"));
            assert_eq!(
                candidates[idx],
                (ip, ports[idx % ports.len()]),
                "anchor {ip} should be tried once, on a port of its own"
            );
        }
    }

    #[test]
    fn the_front_of_the_scan_never_hammers_one_port() {
        let strategy = WgScanMode::Turbo.strategy();
        let ports = [2408, 500, 1701, 4500, 854];
        let candidates = build_wg_candidates(&strategy, &ports, IpScan::V4, &HashSet::new());

        let head: HashSet<u16> = candidates[..ports.len()].iter().map(|(_, p)| *p).collect();
        assert_eq!(
            head.len(),
            ports.len(),
            "the first candidates must spread across ports, not stack on 2408"
        );

        let on_2408 = candidates
            .iter()
            .take(20)
            .filter(|(_, p)| *p == 2408)
            .count();
        assert!(
            on_2408 <= 4,
            "port 2408 took {on_2408} of the first twenty slots"
        );
    }

    #[test]
    fn turbo_tries_every_address_once_before_repeating_any() {
        let strategy = WgScanMode::Turbo.strategy();
        let ports = [2408, 500, 1701, 4500, 854];
        let candidates = build_wg_candidates(&strategy, &ports, IpScan::V4, &HashSet::new());

        let mut per_ip: std::collections::HashMap<IpAddr, usize> = std::collections::HashMap::new();
        for (ip, _) in &candidates {
            *per_ip.entry(*ip).or_default() += 1;
        }

        let repeated = per_ip.values().filter(|count| **count > 1).count();
        assert!(
            repeated <= wireguard::wg_seeds_v4().len(),
            "only an anchor that the pool also sampled may appear twice, saw {repeated}"
        );
        assert!(
            per_ip.values().all(|count| *count <= 2),
            "no address should be tried more than twice in turbo"
        );
    }

    #[test]
    fn sampled_ips_receive_multiple_rotated_port_attempts() {
        let mut strategy = WgScanMode::Balanced.strategy();
        strategy.sample_per_cidr = 1;
        let candidates = build_wg_candidates(
            &strategy,
            &[2408, 500, 1701, 4500],
            IpScan::V4,
            &HashSet::new(),
        );
        let anchors: HashSet<IpAddr> = wireguard::wg_seeds_v4()
            .into_iter()
            .map(|seed| IpAddr::V4(seed.parse().expect("wireguard seed")))
            .collect();
        let mut ports_per_ip: HashMap<IpAddr, HashSet<u16>> = HashMap::new();

        for (ip, port) in candidates {
            if !anchors.contains(&ip) {
                ports_per_ip.entry(ip).or_default().insert(port);
            }
        }

        assert!(
            ports_per_ip.values().any(|ports| ports.len() >= 3),
            "sampled IPs should be tried across multiple port waves"
        );
    }

    fn result(ip: &str, port: u16, rtt_ms: u64) -> WgProbeResult {
        WgProbeResult {
            ip: ip.parse().unwrap(),
            port,
            rtt: Duration::from_millis(rtt_ms),
        }
    }

    #[test]
    fn two_ports_on_one_edge_count_as_a_single_choice() {
        let found = vec![
            result("162.159.192.1", 2408, 40),
            result("162.159.192.1", 500, 30),
            result("162.159.192.1", 1701, 50),
        ];
        let picked = distinct_by_ip(&found);
        assert_eq!(picked.len(), 1, "one address must not fill both gool hops");
        assert_eq!(picked[0].port, 500, "the quickest port on it is kept");
    }

    #[test]
    fn separate_edges_are_offered_quickest_first() {
        let found = vec![
            result("162.159.193.7", 2408, 90),
            result("162.159.192.1", 2408, 20),
            result("162.159.192.1", 500, 25),
            result("162.159.195.4", 4500, 55),
        ];
        let picked = distinct_by_ip(&found);
        assert_eq!(picked.len(), 3);
        assert_eq!(picked[0].ip.to_string(), "162.159.192.1");
        assert_eq!(picked[1].ip.to_string(), "162.159.195.4");
        assert_eq!(picked[2].ip.to_string(), "162.159.193.7");
        assert_ne!(
            picked[0].ip, picked[1].ip,
            "gool must get two different addresses"
        );
    }

    #[test]
    fn nothing_verified_means_nothing_offered() {
        assert!(distinct_by_ip(&[]).is_empty());
    }

    #[test]
    fn cooled_down_endpoint_is_excluded_from_the_scan() {
        let strategy = WgScanMode::Turbo.strategy();
        let peer: SocketAddr = "162.159.192.1:2408".parse().unwrap();
        let excluded = HashSet::from([peer]);
        let candidates =
            build_wg_candidates(&strategy, &[2408, 500, 1701, 4500], IpScan::V4, &excluded);

        assert!(!candidates.contains(&(peer.ip(), peer.port())));
    }
}
